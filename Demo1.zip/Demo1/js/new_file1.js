window.onload = function() {
	var ba = document.getElementById('search');
	var bb = document.getElementById('button');
	var bc = document.getElementById('biao');

	bb.onclick = function() {
		for(var i = 0; i < bc.tBodies[0].rows.length; i++) {
			var bd = bc.tBodies[0].rows[i].cells[1].innerHTML.toLowerCase();
			var be = ba.value.toLowerCase();
			var bf = be.split(' ');

			bc.tBodies[0].rows[i].style.background = '';
			for(var j = 0; j < bf.length; j++) {
//				alert(bf[j].length==0);
				if(bd.search(bf[j]) == 0) {
					if(bf[j].length == 0) {
						bc.tBodies[0].rows[i].style.background = '';
					} else {
						if(bd.search(bf[j]) != -1) {
							bc.tBodies[0].rows[i].style.background = 'yellow';
						}
					}
				} else {
					if(bd.search(bf[j]) != -1) {
						bc.tBodies[0].rows[i].style.background = 'yellow';
					}
				}
			}
		}
	}

};