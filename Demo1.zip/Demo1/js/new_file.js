window.onload = function() {
	var ba = document.getElementById('biao');
	var bb = document.getElementById('name');
	var bc = document.getElementById('age');
	var bd = document.getElementById('button');
	var id= ba.tBodies[0].rows.length + 1

	bd.onclick = function() {
		var be = document.createElement('tr');

		if(bb.value == 0||bc.value == 0) {
            if (bb.value == 0) {
            	if (bc.value == 0) {
            		alert('请输入姓名和年龄');
            	} else{
            		alert('请输入姓名');
            	}
            } else{
            	alert('请输入年龄');
            }
		} else {
			var bf = document.createElement('td');
			bf.innerHTML = id++;
			be.appendChild(bf);

			var bf = document.createElement('td');
			bf.innerHTML = bb.value;
			be.appendChild(bf);

			var bf = document.createElement('td');
			bf.innerHTML = bc.value;
			be.appendChild(bf);

			var bf = document.createElement('td');
			bf.innerHTML = '<a href="javacript:;">删除</a>';
			be.appendChild(bf);

			bf.getElementsByTagName('a')[0].onclick = function() {
				ba.tBodies[0].removeChild(this.parentNode.parentNode);
			}
		}

		ba.tBodies[0].appendChild(be);
	}

};