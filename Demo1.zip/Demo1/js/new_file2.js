window.onload=function  () {
	var bb=document.getElementById('yu');
	bb.onmouseover=function  () {
		show(100);
	}
	bb.onmouseout=function  () {
		show(30);
	}
}

var time=null;
var bc=30;

function show (ba) {
	var bb=document.getElementById('yu');
	
	clearInterval(time);
	time=setInterval(function(){
		var speed=0;
		if (bc<ba) {
			speed=2;
		} else{
			speed=-2;
		}
		if (bc==ba) {
			clearInterval(time);
		} else{
			bc+=speed;
			
			bb.style.filter='alpha(opacity:'+bc+')';
			bb.style.opacity=bc/100;
		}
		
	},30);
}