window.onload=function  () {
	var ba=document.getElementById('xu');
	ba.onmouseover=function  () {
		show(0);
	}
	ba.onmouseout=function  () {
		show(-200);
	}
};

var time=null;

function show (bc) {
	var ba=document.getElementById('xu');
	
	
	clearInterval(time);
	time=setInterval(function  () {
		var speed=0;
		if (ba.offsetLeft<bc) {
			speed=10;
		} else{
			speed=-10;
		}
		if (ba.offsetLeft==bc) {
			clearInterval(time);
		} else{
			ba.style.left=ba.offsetLeft+speed+'px';
			
		}
	},30)
}