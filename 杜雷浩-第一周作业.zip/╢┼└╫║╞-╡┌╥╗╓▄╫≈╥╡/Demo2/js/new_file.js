function show(){
		var ba=document.getElementById('ni');
		setInterval(function(){
	    	var speed=(500-ba.offsetLeft)/10;
	    	speed=speed>0?Math.ceil(speed):Math.floor(speed);
	    	ba.style.left=ba.offsetLeft+speed+'px';
	    	
	    },30);
	    function we(){
	    	var speed=(500-ba.offsetLeft)/10;
	    	
	    	ba.style.left=ba.offsetLeft+speed+'px';
	    	
	    };
};