var timer = null;

function startMove(iTarget) {
	var oDiv = document.getElementById('div1');

	clearInterval(timer);
	timer = setInterval(function() {
		var speed = 0;

		if(oDiv.offsetLeft < iTarget) {
			speed = 7;
		} else {
			speed = -7;
		}

		if(Math.abs(iTarget - oDiv.offsetLeft) <= 7) {
			clearInterval(timer);

			oDiv.style.left = iTarget + 'px';
		} else {
			oDiv.style.left = oDiv.offsetLeft + speed + 'px';
		}
	}, 30);
}