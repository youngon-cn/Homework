window.onscroll = function() {
	var oDiv = document.getElementById('div1');
	var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
	startMove(document.documentElement.clientHeight - oDiv.offsetHeight + scrollTop);
};

var timer = null;

function startMove(iTarget) {
	var oDiv = document.getElementById('div1');

	clearInterval(timer);
	timer = setInterval(function() {
		var speed = (iTarget - oDiv.offsetTop) / 4;
		speed = speed > 0 ? Math.ceil(speed) : Math.floor(speed);

		if(oDiv.offsetTop == iTarget) {
			clearInterval(timer);
		} else {
			oDiv.style.top = oDiv.offsetTop + speed + 'px';
		}
	}, 30);
}